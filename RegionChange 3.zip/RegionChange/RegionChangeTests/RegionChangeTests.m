//
//  RegionChangeTests.m
//  RegionChangeTests
//
//  Created by imayaselvan r. on 14/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "RegionChangeTests.h"

@implementation RegionChangeTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in RegionChangeTests");
}

@end
